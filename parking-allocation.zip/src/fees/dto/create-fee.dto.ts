export class CreateFeeDto {}
