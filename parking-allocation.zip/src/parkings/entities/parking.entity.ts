import {
  BeforeInsert,
  BeforeUpdate,
  Column,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity({ name: 'parkings' })
export class Parking {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  parkingSlotId: number;

  @Column()
  vehicleId: number;

  @Column()
  timeIn: Date;

  @Column()
  timeOut: Date;

  @Column()
  createdAt: Date;

  @Column()
  updatedAt: Date;

  @BeforeInsert()
  setValues() {
    this.updatedAt = this.createdAt = new Date();
    this.timeIn = new Date();
    this.timeOut = null;
  }

  @BeforeUpdate()
  setUpdatedAtValue() {
    this.updatedAt = new Date();
  }
}

export type ParkingWithFee = Partial<Parking> & {
  fee: number;
};
