export class CreateEntryPointDto {}
