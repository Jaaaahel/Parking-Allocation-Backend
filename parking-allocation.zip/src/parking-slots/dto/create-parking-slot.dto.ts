export class CreateParkingSlotDto {}
